/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crypto.sn;

import java.security.Key;
import javax.crypto.SecretKey;

/**
 *
 * @author Amina SARR
 */
public interface Icrypto {
       public final int keysize = 128;
       public final byte[] IV = "Asiezecaracteres".getBytes();
       public final String Algo = "AES";
       public final String transform = "AES/CBC/PKCS5Padding";

    /**
     * Cette mthode permet de generer une cle
     *
     * @param algo:L'algorithme de chiffrement (ex:"AES,"DES")
     * @param keySize:La taille de la cle (ex:128,256)
     * @return La cle generee
     */
    public SecretKey genKey();

    /**
     * Cle @param : La cle generee
     *
     * @param key
     * @param filetPath:Le chemin choisi pour Stocker le fichier contenant la cle
     * @return :Le chemin choisi
     */
    public String saveKey(SecretKey key, String filePath);

    /**
     * @param filePath: Le chemin du fichier ou est stocke notre cle
     * @return : la cle contenudans le fichier
     */
    public SecretKey getKey(String filePath);

    public void Chiffrement( String  keyfile , String fileEncrupt);
    public void Dechiffrement(String keyfile, String fileDcrypt);
}
