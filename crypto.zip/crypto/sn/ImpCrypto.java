/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crypto.sn;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.swing.JFileChooser;

/**
 *
 * @author Amina SARR
 */
public class ImpCrypto implements Icrypto {

    @Override
    public SecretKey genKey() {
        try {
            KeyGenerator gen = KeyGenerator.getInstance(Algo);
            gen.init(keysize);
            SecretKey key = gen.generateKey();

            return key;
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(ImpCrypto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public String saveKey(SecretKey key, String keyfile) {

        try {
            FileOutputStream fos = new FileOutputStream(keyfile);
            ObjectOutputStream obj = new ObjectOutputStream(fos);
            obj.writeObject(key);
            obj.close();
            fos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ImpCrypto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ImpCrypto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    @Override
    public SecretKey getKey(String keyfile) {
        try {
            FileInputStream fis = new FileInputStream(keyfile);
            ObjectInputStream ois = new ObjectInputStream(fis);
            SecretKey key = (SecretKey) ois.readObject();
            return key;
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ImpCrypto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ImpCrypto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ImpCrypto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public Cipher getCipher(String keyfile, int mode) {

        try {
            Cipher c = Cipher.getInstance(transform);
            IvParameterSpec iv = new IvParameterSpec(IV);
            c.init(mode, getKey(keyfile), iv);
            return c;
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(ImpCrypto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchPaddingException ex) {
            Logger.getLogger(ImpCrypto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(ImpCrypto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidAlgorithmParameterException ex) {
            Logger.getLogger(ImpCrypto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    @Override
    public void Chiffrement(String keyfile, String fileEcrypt) {
        try {
            FileInputStream fis = new FileInputStream(fileEcrypt);
            CipherInputStream cis = new CipherInputStream(fis, getCipher(keyfile, Cipher.ENCRYPT_MODE));
            FileOutputStream fos = new FileOutputStream(fileEcrypt + ".sn");
            byte[] buffer = new byte[2048];
            int nbrbute = 0;
            while ((nbrbute = cis.read(buffer)) != -1) {
                fos.write(buffer, 0, nbrbute);
            }
            cis.close();
            fis.close();
            fos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ImpCrypto.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ImpCrypto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    JFileChooser jfc = new JFileChooser();

    public void Enregistfile(SecretKey key) {
        int option = jfc.showSaveDialog(jfc);

        if (JFileChooser.APPROVE_OPTION == option) {
            String filePath = jfc.getSelectedFile().getAbsolutePath();
            this.saveKey(key, filePath);
        }
        String encoding = Base64.getEncoder().encodeToString(key.getEncoded());
        System.out.println(encoding);
    }

    public String OuvretFile(SecretKey key) {
        int option = jfc.showOpenDialog(jfc);
        if (JFileChooser.APPROVE_OPTION == option) {
            String keyfile = jfc.getSelectedFile().getAbsolutePath();
            key = this.getKey(keyfile);

        }
        String encoding2 = Base64.getEncoder().encodeToString(key.getEncoded());
        System.out.println(encoding2);
        return null;

    }

    public String OpenFileEncrypt() {

        int option = jfc.showOpenDialog(jfc);
        if (JFileChooser.APPROVE_OPTION == option) {
            String fileEncrypt = jfc.getSelectedFile().getAbsolutePath();
        }
        return null;
    }

    public void affichage(SecretKey key) {
        JFileChooser jfc = new JFileChooser();
        //int option = jfc.showSaveDialog(jfc);
        int option = jfc.showOpenDialog(jfc);

        if (JFileChooser.APPROVE_OPTION == option) {
            String filePath = jfc.getSelectedFile().getAbsolutePath();
            this.saveKey(key, filePath);
        }
        String encoding = Base64.getEncoder().encodeToString(key.getEncoded());
        System.out.println(encoding);
    }

    @Override
    public void Dechiffrement(String keyfile, String fileDEcrypt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
