/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crypto.sn;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;

/**
 *
 * @author Amina SARR
 */
public class Test {
     public static void main(String[] args) {
        ImpCrypto  crypto = new ImpCrypto();
         SecretKey key = crypto.genKey();
         crypto.Enregistfile(key);
        String keyFile = crypto.OuvretFile(key);
        String fileEncrypt = crypto.OpenFileEncrypt();
        crypto.getCipher(keyFile, Cipher.ENCRYPT_MODE);
         String keyfile = null;
        crypto.Chiffrement(fileEncrypt,keyfile);
    }
    
    
}
